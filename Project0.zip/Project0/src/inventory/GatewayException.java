package inventory;

public class GatewayException extends Exception {
	public GatewayException(String s) {
		super(s);
	}
}

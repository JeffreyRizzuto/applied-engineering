package inventory;

import java.util.HashMap;

public interface ProductGateway {
	
	public void close();
}
